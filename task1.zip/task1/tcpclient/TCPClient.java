package tcpclient;

import java.net.*;
import java.io.*;

public class TCPClient {

    public TCPClient() {
    }

    public byte[] askServer(String hostname, int port, byte[] toServerBytes) throws IOException, UnknownHostException {

        // Create a socket and connect it to the server
        Socket clientSocket = new Socket(hostname, port);

        // Send byte array to server on the socket, no need for offset or length since it has been made exactly from
        // a string. No empty indexes in the array.
        clientSocket.getOutputStream().write(toServerBytes);

        // Server answer with a byte array which is stored in fromServerBuffer. askServer only returns the actual
        // message sent and therefore the length is not needed.
        //clientSocket.getInputStream().read(fromServerBuffer);
        ByteArrayOutputStream fromServerBuffer = new ByteArrayOutputStream();
        int data = clientSocket.getInputStream().read();
        while(data != - 1) {
            fromServerBuffer.write(data);
            data = clientSocket.getInputStream().read();
        }

        // Terminate the connection between the sockets.
        clientSocket.close();


        return fromServerBuffer.toByteArray();
    }
}
